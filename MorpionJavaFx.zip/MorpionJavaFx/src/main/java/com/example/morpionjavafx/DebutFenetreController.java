package com.example.morpionjavafx;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
public class DebutFenetreController {


    //quitter app

    @FXML
    private void handleBouttonQUITTERAction(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    private void handleBoutonCOMMENCERAction(ActionEvent event) {
        try {
            // Load the FXML file for the hello-view window
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/morpionjavafx/hello-view.fxml"));

            // Create a new scene with the loaded parent
            Scene scene = new Scene(fxmlLoader.load());

            // Create a new stage
            Stage stage = new Stage();

            // Set the modality
            stage.initModality(Modality.APPLICATION_MODAL);

            // Set the scene of the stage to the new scene
            stage.setScene(scene);

            // Show the stage
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void handleBoutonREGLESAction(ActionEvent event) {
        try {
            // Load the FXML file for the rules window
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/morpionjavafx/regles.fxml"));

            // Create a new scene with the loaded parent
            Scene scene = new Scene(fxmlLoader.load());

            // Create a new stage
            Stage stage = new Stage();

            // Set the modality
            stage.initModality(Modality.APPLICATION_MODAL);

            // Set the scene of the stage to the new scene
            stage.setScene(scene);

            // Show the stage
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void handleButtonScoreTable(ActionEvent event) {
        try {
            // Charger le fichier FXML pour le tableau de scores
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/morpionjavafx/Tableau.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène avec le tableau de scores
            Scene scene = new Scene(root);

            // Créer une nouvelle fenêtre (stage) pour le tableau de scores
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }







}