package com.example.morpionjavafx;


import javafx.scene.layout.Pane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.layout.Pane;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

public class reglesController {

    @FXML
    private Pane videoPane;
    @FXML
    private MediaPlayer mediaPlayer;



    @FXML
    private void QuitterRegleAction(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            videoPane.setDisable(true);

        }

        stage.close();

    }


    @FXML
    private void ToujourspasCompriAction(ActionEvent event) {
        String path = "/Règle du jeu Morpion.mp4";
        Media media = new Media(getClass().getResource(path).toExternalForm());
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        MediaView mediaView = new MediaView(mediaPlayer);

        videoPane.getChildren().add(mediaView);

        mediaPlayer.play();
    }




}