package com.example.morpionjavafx;

import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.text.Text;

import javax.swing.*;
import java.time.LocalDate;

public class HelloController {


    @FXML
    private Ellipse LeRondBlueueQuiPermetDeSavoirQuiJoue, LeRondRougeQuiPermetDeSavoirQuiJoue;
    @FXML
    private boolean rondRouge = false;
    @FXML
    private boolean rondBleue = false;

    @FXML
    private TextField EntrerNomJoueurTEXT;
    @FXML
    private Button BouittonPOurValiderNomJoueur1, BouittonPOurValiderNomJoueur2;
    @FXML
    private Label LeNomDuJoueur1, LeNomDuJoueur2;

    @FXML
    private Label welcomeText;

    @FXML
    private Label ScoreJoueur1, ScoreJoueur2;

    @FXML
    private Button button1, button2, button3, button4, button5, button6, button7, button8, button9;
    @FXML
    // Tableau pour stocker les boutons
    private Button[][] buttons;
    @FXML
    // Variable pour suivre le tour actuel
    private boolean turn = true; // true pour "X" sinon false pour "O"


    @FXML
    private Button BoutonCommencePartieJoueur1, BoutonCommencePartieJoueur2;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private Label gameResultLabel;

    @FXML
    private Text LeScoreEnNombreDepointsAAfficherEtAChangerIciPourJoueur1, LeScoreEnNombreDepointsAAfficherEtAChangerIciPourJoueur2;


    @FXML
    private Button RecommencerPartie; // Assurez-vous que ce bouton est défini dans votre fichier FXML







    @FXML
    public void initialize() {
        buttons = new Button[][] {
                {button1, button2, button3},
                {button4, button5, button6},
                {button7, button8, button9}
        };

        // Désactiver tous les boutons du jeu tant quon a pas choisi un joueur qui commence
        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setDisable(true);
            }
        }
    }



    @FXML
    protected void handleBoutonCommencePartieJoueur1Action() {
        turn = true; // Player 1 starts the game
        BoutonCommencePartieJoueur1.setDisable(true); // Désactive le bouton après qu'il ait été cliqué
        BoutonCommencePartieJoueur2.setDisable(true); // Désactive aussi l'autre bouton

        // Réactiver tous les boutons du jeu
        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setDisable(false);
            }
        }
    }

    @FXML
    protected void handleBoutonCommencePartieJoueur2Action() {
        turn = false; // Player 2 starts the game
        BoutonCommencePartieJoueur1.setDisable(true); // Désactive le bouton après qu'il ait été cliqué
        BoutonCommencePartieJoueur2.setDisable(true); // Désactive aussi l'autre bouton

        // Réactiver tous les boutons du jeu
        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setDisable(false);
            }
        }
    }





    @FXML

    private boolean checkWin(String player) {
        for (int i = 0; i < 3; i++) {
            if (buttons[i][0].getText().equals(player) && buttons[i][1].getText().equals(player) && buttons[i][2].getText().equals(player)) {
                return true;
            }
            if (buttons[0][i].getText().equals(player) && buttons[1][i].getText().equals(player) && buttons[2][i].getText().equals(player)) {
                return true;
            }
        }
        if (buttons[0][0].getText().equals(player) && buttons[1][1].getText().equals(player) && buttons[2][2].getText().equals(player)) {
            return true;
        }
        if (buttons[0][2].getText().equals(player) && buttons[1][1].getText().equals(player) && buttons[2][0].getText().equals(player)) {
            return true;
        }
        return false;
    }





    private boolean checkDraw() {
        for (Button[] row : buttons) {
            for (Button button : row) {
                if (button.getText().isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }




    private int scoreJoueur1 = 0; // Score du joueur 1
    private int scoreJoueur2 = 0; // Score du joueur 2

//qui gagne
    @FXML
    protected void handleButtonAction(ActionEvent event) {
        Button button = (Button) event.getSource();

        if (!button.getText().isEmpty()) {
            return;
        } else {
            String player;
            if (turn) {
                player = "X";
                button.setText(player);
                rondBleue= false;
                rondRouge= true;
                updateEllipseOpacity();
            } else {
                player = "O";
                button.setText(player);
                rondRouge= false;
                rondBleue= true;
                updateEllipseOpacity();
            }
            turn= !turn;

            if (checkWin(player)) {
                // Le joueur a gagné
                if (player.equals("X")) {
                    gameResultLabel.setText(LeNomDuJoueur1.getText() + " a gagné !");
                    scoreJoueur1++; // Incrémente le score du joueur 1
                } else if (player.equals("O")) {
                    gameResultLabel.setText(LeNomDuJoueur2.getText() + " a gagné !");
                    scoreJoueur2++; // Incrémente le score du joueur 2
                }
                updateScores(); // Met à jour l'affichage des scores
                endGame(); // fin du jeu

            } else if (checkDraw()) {
                // Match nul
                gameResultLabel.setText("Match nul !");
                endGame();
            }
        }
    }


    private void updateScores() {
        LeScoreEnNombreDepointsAAfficherEtAChangerIciPourJoueur1.setText(String.valueOf(scoreJoueur1));
        LeScoreEnNombreDepointsAAfficherEtAChangerIciPourJoueur2.setText(String.valueOf(scoreJoueur2));
    }


    private boolean AfficherLesBouttonGAgnant(Button button) {
        String player = button.getText();
        if (player.isEmpty()) {
            return false;
        }

        for (int i = 0; i < 3; i++) {
            if (buttons[i][0] == button || buttons[i][1] == button || buttons[i][2] == button) {
                if (buttons[i][0].getText().equals(player) && buttons[i][1].getText().equals(player) && buttons[i][2].getText().equals(player)) {
                    return true;
                }
            }
            if (buttons[0][i] == button || buttons[1][i] == button || buttons[2][i] == button) {
                if (buttons[0][i].getText().equals(player) && buttons[1][i].getText().equals(player) && buttons[2][i].getText().equals(player)) {
                    return true;
                }
            }
        }
        if (buttons[0][0] == button || buttons[1][1] == button || buttons[2][2] == button) {
            if (buttons[0][0].getText().equals(player) && buttons[1][1].getText().equals(player) && buttons[2][2].getText().equals(player)) {
                return true;
            }
        }
        if (buttons[0][2] == button || buttons[1][1] == button || buttons[2][0] == button) {
            if (buttons[0][2].getText().equals(player) && buttons[1][1].getText().equals(player) && buttons[2][0].getText().equals(player)) {
                return true;
            }
        }
        return false;
    }




    @FXML

    private void endGame() {
        DropShadow shadow = new DropShadow();
        // la couleur de l'ombre  (rouge)
        shadow.setColor(Color.rgb(255, 0, 0, 0.29));

        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setDisable(true);
                if (AfficherLesBouttonGAgnant(button)) {
                    button.setEffect(shadow);  //effet d'ombre

                } else {
                    button.setText(""); // Réinitialise le texte du bouton si il ne fait pas partie d'une ligne gagnante
                }
            }
        }
        RecommencerPartie.setOpacity(1); // Rend le bouton RecommencerPartie visible
    }

    @FXML


    //fonction pour savoir qui joue grace aux ronds
    public void updateEllipseOpacity() {
        if (rondRouge) {
            LeRondRougeQuiPermetDeSavoirQuiJoue.setOpacity(1);
            LeRondBlueueQuiPermetDeSavoirQuiJoue.setOpacity(0);
        } else if (rondBleue) {
            LeRondRougeQuiPermetDeSavoirQuiJoue.setOpacity(0);
            LeRondBlueueQuiPermetDeSavoirQuiJoue.setOpacity(1);
        }
    }



    //fonction pour changer le nom des joueur en utilisant le onAction des bouttons
    @FXML
    protected void handleBouittonPOurValiderNomJoueur1Action() {
        String nomJoueur = EntrerNomJoueurTEXT.getText();
        LeNomDuJoueur1.setText(nomJoueur);
    }

    @FXML
    protected void handleBouittonPOurValiderNomJoueur2Action() {
        String nomJoueur = EntrerNomJoueurTEXT.getText();
        LeNomDuJoueur2.setText(nomJoueur);
    }

    @FXML
    public void handleRecommencerPartieAction() {

        DropShadow shadow = new DropShadow();

        shadow.setColor(Color.rgb(0, 0, 0, 0));// une opacité de 0.29 et couleur rouge

        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setDisable(true); // Désactive le bouton
                if (AfficherLesBouttonGAgnant(button)) {
                    // Si le bouton fait partie de la ligne gagnante, appliquez l'effet d'ombre
                    button.setEffect(shadow);
                }
            }
        }
        gameResultLabel.setText("");
        resetGame();
    }

    @FXML

    private void resetGame() {
        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setDisable(false); // Réactive le bouton
                button.setText(""); // Réinitialise le texte du bouton
            }
        }
        RecommencerPartie.setOpacity(0); // Rend le bouton RecommencerPartie invisible

        BoutonCommencePartieJoueur1.setDisable(false);
        BoutonCommencePartieJoueur2.setDisable(false);
    }


    @FXML
    private Button ImagesButton;
    private boolean buttonImage = false;

    @FXML
    protected void handleButtonImage(ActionEvent event) {
        buttonImage = true;
    }






}


