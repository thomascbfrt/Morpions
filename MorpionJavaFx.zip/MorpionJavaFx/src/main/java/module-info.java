module com.example.morpionjavafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.media;


    opens com.example.morpionjavafx to javafx.fxml;
    exports com.example.morpionjavafx;
}